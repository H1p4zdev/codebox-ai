export type TelemetrySetting = "unset" | "enabled" | "disabled"
