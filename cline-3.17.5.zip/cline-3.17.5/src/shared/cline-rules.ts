export type ClineRulesToggles = Record<string, boolean> // filepath -> enabled/disabled
