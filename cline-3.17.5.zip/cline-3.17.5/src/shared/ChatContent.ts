export interface ChatContent {
	message?: string
	images?: string[]
}
