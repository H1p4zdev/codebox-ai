const stubs = require("./vscode-stubs.js")
const impls = require("./vscode-impls.js")

module.exports = {
	...stubs,
	...impls,
}
